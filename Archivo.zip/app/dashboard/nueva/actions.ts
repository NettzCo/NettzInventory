"use server";

import { createClient } from "@/lib/supabase/server";
import { getCurrentProfile } from "@/lib/currentProfile";
import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { ESTADOS_SIM, PLAN_UNIDADES, TIPOS_PLAN, PAGOS_MOMENTO } from "@/lib/types";
import { hoyColombia, fechaColombiaATimestamp } from "@/lib/ui";
import { encontrarClienteSimilarConTipo, emparejarValorInsensible } from "@/lib/textMatch";

export interface SimRowInput {
  icc: string;
  proveedor: string;
  numero_corto: string;
  estado_entrega: string;
  fecha_activacion: string; // solo relevante si estado_entrega === "Activa"; puede ser una fecha pasada
  apn: string;
  observaciones: string;
}

export interface EntregaInput {
  cliente_nombre: string;
  plan_unidad: string;
  plan_cantidad: string;
  tipo_plan: string;
  pago_momento: string;
  duracion_meses: string; // "" cuando no aplica (Postpago)
  precio_cliente: string;
  fecha_entrega: string;
  comercial_id: string;
  broker_id: string;
  sims: SimRowInput[];
}

export async function crearEntrega(input: EntregaInput) {
  const { userId, profile } = await getCurrentProfile();
  const supabase = await createClient();

  // Validaciones básicas de campos obligatorios
  if (
    !input.cliente_nombre?.trim() ||
    !input.plan_unidad ||
    !input.plan_cantidad ||
    !input.tipo_plan ||
    !input.pago_momento ||
    !input.precio_cliente ||
    !input.comercial_id
  ) {
    return { error: "Faltan campos obligatorios de la entrega." };
  }

  // fecha_entrega es opcional: si no se indica, se usa la fecha de hoy
  // (fecha de creación del registro).
  const fechaEntregaFinal = input.fecha_entrega || hoyColombia();

  if (!input.sims.length) {
    return { error: "Agrega al menos una SIM card." };
  }

  for (const [i, sim] of input.sims.entries()) {
    if (!sim.icc?.trim() || !sim.proveedor?.trim() || !sim.estado_entrega) {
      return { error: `Falta información obligatoria en la SIM #${i + 1} (ICC, proveedor y estado son obligatorios).` };
    }
    if (sim.proveedor.trim().toLowerCase() === "claro" && !sim.numero_corto?.trim()) {
      return { error: `La SIM #${i + 1} es de Claro: el número corto es obligatorio.` };
    }
  }

  const createdIds: string[] = [];

  const { data: operacion, error: errorOperacion } = await supabase
    .from("bulk_operations")
    .insert({
      organization_id: profile.organization_id,
      tipo: "registro_entrega",
      cantidad_sims: input.sims.length,
      nota: `Entrega a ${input.cliente_nombre.trim()} (${input.sims.length} SIM)`,
      created_by: userId,
    })
    .select("id")
    .single();

  if (errorOperacion) {
    return { error: errorOperacion.message };
  }
  const operacionId = operacion.id as string;

  for (const sim of input.sims) {
    const { data: existente } = await supabase
      .from("sim_cards")
      .select("id")
      .eq("icc", sim.icc.trim())
      .maybeSingle();

    if (existente) {
      return {
        error: `La SIM con ICC ${sim.icc.trim()} ya existe en el inventario.`,
        existingSimId: existente.id,
        partialSuccess: createdIds.length > 0,
      };
    }

    const { data: simCard, error: simError } = await supabase
      .from("sim_cards")
      .insert({
        organization_id: profile.organization_id,
        icc: sim.icc.trim(),
        proveedor: sim.proveedor.trim(),
        apn: sim.apn?.trim() || null,
        observaciones: sim.observaciones?.trim() || null,
        created_by: userId,
      })
      .select("id")
      .single();

    if (simError) {
      return { error: simError.message, partialSuccess: createdIds.length > 0 };
    }

    const simId = simCard.id as string;
    createdIds.push(simId);

    const { error: errorEstado } = await supabase.from("sim_status_history").insert({
      sim_id: simId,
      estado: sim.estado_entrega,
      changed_by: userId,
      nota: "Estado inicial en la entrega.",
      bulk_operation_id: operacionId,
      // Si la SIM ya se registra como "Activa" y se indicó una fecha de
      // activación (por ejemplo, para cargar inventario histórico), se usa
      // esa fecha real en vez de la fecha de hoy — así las alertas de
      // vencimiento calculan bien desde el principio.
      ...(sim.estado_entrega === "Activa" && sim.fecha_activacion
        ? { changed_at: fechaColombiaATimestamp(sim.fecha_activacion) }
        : {}),
    });
    if (errorEstado) {
      await supabase.from("sim_cards").delete().eq("id", simId);
      return { error: `No se pudo registrar el estado de la SIM ${sim.icc}: ${errorEstado.message}`, partialSuccess: createdIds.length > 1 };
    }

    if (sim.numero_corto?.trim()) {
      const { error: errorNumero } = await supabase.from("sim_short_numbers").insert({
        sim_id: simId,
        organization_id: profile.organization_id,
        numero_corto: sim.numero_corto.trim(),
        assigned_by: userId,
      });
      if (errorNumero) {
        await supabase.from("sim_cards").delete().eq("id", simId);
        return { error: `No se pudo registrar el número corto de la SIM ${sim.icc}: ${errorNumero.message}`, partialSuccess: createdIds.length > 1 };
      }
    }

    const { error: errorAsignacion } = await supabase.from("sim_assignments").insert({
      sim_id: simId,
      cliente_nombre: input.cliente_nombre.trim(),
      plan_unidad: input.plan_unidad,
      plan_cantidad: Number(input.plan_cantidad),
      tipo_plan: input.tipo_plan,
      pago_momento: input.pago_momento,
      duracion_meses: input.tipo_plan === "Prepago" ? Number(input.duracion_meses) || 12 : null,
      precio_cliente: Number(input.precio_cliente),
      comercial_id: input.comercial_id,
      broker_id: input.broker_id || null,
      fecha_entrega: fechaEntregaFinal,
      created_by: userId,
      bulk_operation_id: operacionId,
    });
    if (errorAsignacion) {
      // No se deja la SIM a medias (con ICC pero sin cliente/plan) — se
      // revierte por completo para que el error sea visible de inmediato.
      await supabase.from("sim_cards").delete().eq("id", simId);
      return { error: `No se pudo asignar el cliente/plan a la SIM ${sim.icc}: ${errorAsignacion.message}`, partialSuccess: createdIds.length > 1 };
    }
  }

  redirect("/dashboard");
}

// ------------------------------------------------------------------
// CARGA MASIVA: cada fila del Excel es una entrega completa e
// independiente (puede ser de clientes distintos). Ver plantilla en
// /templates/plantilla-carga-masiva.xlsx
// ------------------------------------------------------------------

// ------------------------------------------------------------------
// CARGA MASIVA: cada fila del Excel es una entrega completa. Si el ICC
// no existe, se crea. Si ya existe, se actualiza — cerrando los registros
// vigentes y abriendo unos nuevos, para que el cambio quede en la hoja
// de vida de esa SIM (nunca se sobreescribe el historial).
// Ver plantilla en /templates/plantilla-carga-masiva.xlsx
// ------------------------------------------------------------------

const COLUMNAS_ESPERADAS = [
  "icc", "proveedor", "numero_corto", "apn", "observaciones", "estado",
  "cliente_nombre", "plan_unidad", "plan_cantidad", "tipo_plan", "pago_momento",
  "precio_cliente", "fecha_entrega", "comercial_correo", "broker_correo",
];

export interface FilaParseada {
  fila: number;
  icc: string;
  proveedor: string;
  numeroCorto: string;
  apn: string;
  observaciones: string;
  estado: string;
  clienteEscrito: string;
  clienteSugerido: string | null;
  clienteResuelto: string; // el que realmente se va a guardar
  planUnidad: string;
  planCantidad: string;
  tipoPlan: string;
  pagoMomento: string;
  precio: string;
  fechaEntrega: string;
  comercialId: string;
  comercialNombre: string;
  brokerId: string;
  brokerNombre: string;
  esNueva: boolean;
  accionExistente: "reemplazar" | "solo_estado"; // solo aplica cuando esNueva es false
  numeroCortoConflictoIcc: string | null; // ICC de la OTRA sim que hoy tiene este número corto
  resolucionNumeroCorto: "reasignar" | "no_cargar"; // solo aplica si hay conflicto
  errores: string[];
}

async function extraerFilas(formData: FormData): Promise<{ error: string } | { filas: FilaParseada[] }> {
  const file = formData.get("archivo") as File | null;
  if (!file || file.size === 0) {
    return { error: "Selecciona un archivo Excel (.xlsx) para cargar." };
  }

  const ExcelJS = (await import("exceljs")).default;
  const workbook = new ExcelJS.Workbook();

  try {
    const buffer = Buffer.from(await file.arrayBuffer());
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    await workbook.xlsx.load(buffer as any);
  } catch {
    return { error: "No se pudo leer el archivo. Verifica que sea un .xlsx válido." };
  }

  const sheet = workbook.getWorksheet("Carga masiva") ?? workbook.worksheets[0];
  if (!sheet) return { error: "El archivo no tiene hojas de datos." };

  const headerRow = sheet.getRow(1).values as unknown[];
  const headers = headerRow.slice(1).map((h) => String(h ?? "").trim().toLowerCase());

  const missing = COLUMNAS_ESPERADAS.filter((c) => !headers.includes(c));
  if (missing.length) {
    return { error: `Faltan columnas en el archivo: ${missing.join(", ")}. Descarga la plantilla actualizada.` };
  }

  const { profile } = await getCurrentProfile();
  const supabase = await createClient();
  const [{ data: profiles }, { data: proveedoresActivos }, { data: apnsActivos }, { data: asignaciones }, { data: simsExistentes }, { data: numerosAsignados }] = await Promise.all([
    supabase.from("profiles").select("id, full_name").eq("organization_id", profile.organization_id).eq("active", true),
    supabase.from("providers").select("name").eq("active", true),
    supabase.from("apns").select("name").eq("active", true),
    supabase.from("sim_assignments").select("cliente_nombre"),
    supabase.from("sim_cards").select("icc").eq("organization_id", profile.organization_id),
    supabase.from("sim_short_numbers").select("numero_corto, sim_id, sim_cards(icc)").eq("organization_id", profile.organization_id).is("unassigned_at", null),
  ]);

  const iccsExistentes = new Set((simsExistentes ?? []).map((s) => s.icc));

  // Mapa numero_corto -> a qué ICC pertenece hoy, para detectar cuando el
  // archivo intenta asignarle ese número a una SIM distinta.
  const numeroCortoAIcc = new Map<string, { icc: string; simId: string }>();
  for (const n of numerosAsignados ?? []) {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any -- el tipo generado por el join no refleja bien la forma real
    const sim = n.sim_cards as any;
    const icc = Array.isArray(sim) ? sim[0]?.icc : sim?.icc;
    if (icc) numeroCortoAIcc.set(n.numero_corto, { icc, simId: n.sim_id as string });
  }

  const nombreToId = new Map<string, { id: string; full_name: string }>(
    (profiles ?? []).map((p) => [p.full_name.trim().toLowerCase(), { id: p.id, full_name: p.full_name }])
  );
  const proveedoresPorNombre = new Map<string, string>((proveedoresActivos ?? []).map((p) => [p.name.toLowerCase(), p.name]));
  const apnsPorNombre = new Map<string, string>((apnsActivos ?? []).map((a) => [a.name.toLowerCase(), a.name]));
  const clientesExistentes = Array.from(new Set((asignaciones ?? []).map((a) => a.cliente_nombre)));

  const filas: FilaParseada[] = [];
  const rowCount = sheet.rowCount;

  for (let r = 2; r <= rowCount; r++) {
    const row = sheet.getRow(r);
    const values = row.values as unknown[];
    if (!values || values.length <= 1) continue;

    const getRaw = (col: string): unknown => {
      const idx = headers.indexOf(col);
      if (idx === -1) return undefined;
      return values[idx + 1];
    };

    const get = (col: string) => {
      const v = getRaw(col);
      if (v === null || v === undefined) return "";
      // Las celdas de fecha llegan como objeto Date de JavaScript (no como
      // texto) — hay que formatearlas a AAAA-MM-DD explícitamente, porque
      // String(fecha) da algo como "Fri Aug 22 2025 00:00:00 GMT+0000...",
      // que la base de datos rechaza por no ser una fecha válida.
      if (v instanceof Date) {
        const y = v.getFullYear();
        const m = String(v.getMonth() + 1).padStart(2, "0");
        const d = String(v.getDate()).padStart(2, "0");
        return `${y}-${m}-${d}`;
      }
      return String(v).trim();
    };

    // El ICC y el número corto tienen 15-20 dígitos. Si Excel los guardó
    // como NÚMERO (no como texto) en algún punto —por ejemplo, si alguien
    // los escribió a mano en una celda sin formato de texto—, el valor
    // puede llegar YA CORROMPIDO: Excel solo es exacto hasta ~15 cifras, así
    // que los últimos dígitos pueden estar mal sin que se note a simple
    // vista. No hay forma de "recuperar" esos dígitos después del hecho,
    // así que la fila se marca con error en vez de guardar un ICC dudoso.
    function advertirSiEraNumero(col: string, valor: string, errores: string[]) {
      const raw = getRaw(col);
      if (typeof raw === "number") {
        errores.push(
          `${col} llegó como número de Excel, no como texto ("${valor}") — puede haber perdido dígitos. ` +
          `Vuelve a escribirlo en la celda como texto (formato de columna "Texto") y sube el archivo de nuevo.`
        );
      }
    }

    const icc = get("icc");
    if (!icc) continue;

    const proveedorEscrito = get("proveedor");
    const apnEscrito = get("apn");
    const numeroCorto = get("numero_corto");
    const observaciones = get("observaciones");
    // Estos cuatro campos vienen de un desplegable — no importa si en el
    // Excel quedaron en mayúsculas, minúsculas o mezcladas (p. ej.
    // "POSTPAGO", "postpago"): se emparejan contra la lista de valores
    // válidos sin distinguir mayúsculas y se guardan con el formato
    // canónico exacto que espera la base de datos.
    const estadoEscrito = get("estado");
    const estado = emparejarValorInsensible(estadoEscrito, ESTADOS_SIM) ?? estadoEscrito;
    const clienteEscrito = get("cliente_nombre");
    const planUnidadEscrito = get("plan_unidad");
    const planUnidad = emparejarValorInsensible(planUnidadEscrito, PLAN_UNIDADES) ?? planUnidadEscrito;
    const planCantidad = get("plan_cantidad");
    const tipoPlanEscrito = get("tipo_plan");
    const tipoPlan = emparejarValorInsensible(tipoPlanEscrito, TIPOS_PLAN) ?? tipoPlanEscrito;
    const pagoMomentoEscrito = get("pago_momento");
    const pagoMomento = emparejarValorInsensible(pagoMomentoEscrito, PAGOS_MOMENTO) ?? pagoMomentoEscrito;
    const precio = get("precio_cliente");
    const fechaEntrega = get("fecha_entrega");
    const comercialEscrito = get("comercial_correo");
    const brokerEscrito = get("broker_correo");

    const errores: string[] = [];
    advertirSiEraNumero("icc", icc, errores);
    if (numeroCorto) advertirSiEraNumero("numero_corto", numeroCorto, errores);

    const proveedor = proveedoresPorNombre.get(proveedorEscrito.toLowerCase()) ?? proveedorEscrito;
    if (!proveedorEscrito) errores.push("proveedor es obligatorio");
    else if (!proveedoresPorNombre.has(proveedorEscrito.toLowerCase())) {
      errores.push(`proveedor "${proveedorEscrito}" no coincide con ningún proveedor activo`);
    }

    const apn = apnEscrito ? (apnsPorNombre.get(apnEscrito.toLowerCase()) ?? apnEscrito) : "";
    if (apnEscrito && !apnsPorNombre.has(apnEscrito.toLowerCase())) {
      errores.push(`apn "${apnEscrito}" no coincide con ningún APN activo`);
    }

    if (proveedor.toLowerCase() === "claro" && !numeroCorto) errores.push("numero_corto es obligatorio para Claro");
    if (!estado) errores.push("estado es obligatorio");
    else if (!ESTADOS_SIM.includes(estado as never)) errores.push(`estado "${estado}" no es válido`);
    if (!clienteEscrito) errores.push("cliente_nombre es obligatorio");
    if (!planUnidad) errores.push("plan_unidad es obligatorio");
    else if (!PLAN_UNIDADES.includes(planUnidad as never)) errores.push(`plan_unidad "${planUnidad}" no es válido`);
    if (!planCantidad) errores.push("plan_cantidad es obligatorio");
    else if (!Number.isFinite(Number(planCantidad))) errores.push(`plan_cantidad "${planCantidad}" debe ser un número (sin texto ni unidades)`);
    if (!tipoPlan) errores.push("tipo_plan es obligatorio");
    else if (!TIPOS_PLAN.includes(tipoPlan as never)) errores.push(`tipo_plan "${tipoPlan}" no es válido`);
    if (!pagoMomento) errores.push("pago_momento es obligatorio");
    else if (!PAGOS_MOMENTO.includes(pagoMomento as never)) errores.push(`pago_momento "${pagoMomento}" no es válido`);
    if (!precio) errores.push("precio_cliente es obligatorio");
    else if (!Number.isFinite(Number(precio))) errores.push(`precio_cliente "${precio}" debe ser un número (sin puntos ni símbolo de pesos)`);
    // fecha_entrega es opcional: si viene vacía, se usa la fecha de hoy
    // (fecha de creación del registro) — la plantilla de carga masiva no
    // tiene un campo de "fecha de activación" separado.

    const comercial = nombreToId.get(comercialEscrito.toLowerCase());
    if (!comercialEscrito) errores.push("comercial_correo es obligatorio");
    else if (!comercial) errores.push(`comercial_correo "${comercialEscrito}" no coincide con ningún usuario activo`);

    const broker = brokerEscrito ? nombreToId.get(brokerEscrito.toLowerCase()) : undefined;
    if (brokerEscrito && !broker) errores.push(`broker_correo "${brokerEscrito}" no coincide con ningún usuario activo`);

    const coincidenciaCliente = clienteEscrito ? encontrarClienteSimilarConTipo(clienteEscrito, clientesExistentes) : null;
    // Si el nombre coincide EXACTO salvo mayúsculas/tildes/espacios (p. ej.
    // "MOTORASTREO" vs "Motorastreo"), es sin duda el mismo cliente — se usa
    // directamente el nombre ya registrado, sin preguntarle nada a la
    // persona. Solo se pide confirmación cuando la coincidencia es
    // aproximada (un posible typo), porque ahí sí puede ser un cliente
    // distinto que solo se parece.
    const necesitaConfirmar = coincidenciaCliente?.tipo === "aproximada";
    const clienteSugerido = necesitaConfirmar ? coincidenciaCliente!.nombre : null;
    const clienteInicial = coincidenciaCliente?.tipo === "exacta" ? coincidenciaCliente.nombre : clienteEscrito;

    // ¿Este número corto ya está asignado hoy a una SIM DISTINTA a la de esta fila?
    const dueñoActual = numeroCorto ? numeroCortoAIcc.get(numeroCorto) : undefined;
    const numeroCortoConflictoIcc = dueñoActual && dueñoActual.icc !== icc ? dueñoActual.icc : null;

    filas.push({
      fila: r,
      icc,
      proveedor,
      numeroCorto,
      apn,
      observaciones,
      estado,
      clienteEscrito,
      clienteSugerido,
      // Si hubo coincidencia exacta, ya se guarda el nombre canónico
      // existente. Si es aproximada, se guarda el texto tal cual hasta que
      // la persona confirme si es o no el mismo cliente.
      clienteResuelto: clienteInicial,
      planUnidad,
      planCantidad,
      tipoPlan,
      pagoMomento,
      precio,
      fechaEntrega: fechaEntrega || hoyColombia(),
      comercialId: comercial?.id ?? "",
      comercialNombre: comercial?.full_name ?? comercialEscrito,
      brokerId: broker?.id ?? "",
      brokerNombre: broker?.full_name ?? brokerEscrito,
      esNueva: !iccsExistentes.has(icc),
      accionExistente: "reemplazar",
      numeroCortoConflictoIcc,
      resolucionNumeroCorto: "no_cargar",
      errores,
    });
  }

  // ---- Duplicados DENTRO del mismo archivo (no contra la base de datos) ----
  const filasPorIcc = new Map<string, number[]>();
  const filasPorNumeroCorto = new Map<string, number[]>();
  for (const f of filas) {
    if (f.icc) filasPorIcc.set(f.icc, [...(filasPorIcc.get(f.icc) ?? []), f.fila]);
    if (f.numeroCorto) filasPorNumeroCorto.set(f.numeroCorto, [...(filasPorNumeroCorto.get(f.numeroCorto) ?? []), f.fila]);
  }
  for (const f of filas) {
    const filasConMismoIcc = filasPorIcc.get(f.icc) ?? [];
    if (filasConMismoIcc.length > 1) {
      f.errores.push(`ICC repetido en el archivo (también en la fila ${filasConMismoIcc.filter((n) => n !== f.fila).join(", ")})`);
    }
    if (f.numeroCorto) {
      const filasConMismoNumero = filasPorNumeroCorto.get(f.numeroCorto) ?? [];
      if (filasConMismoNumero.length > 1) {
        f.errores.push(`Número corto "${f.numeroCorto}" repetido en el archivo (también en la fila ${filasConMismoNumero.filter((n) => n !== f.fila).join(", ")})`);
      }
    }
  }

  return { filas };
}

/** FASE 1: lee y valida el archivo, detecta clientes parecidos, y NO guarda nada todavía. */
export async function analizarCargaMasiva(formData: FormData) {
  await getCurrentProfile();
  const resultado = await extraerFilas(formData);
  if ("error" in resultado) return { error: resultado.error };
  if (resultado.filas.length === 0) return { error: "El archivo no tiene filas con datos." };
  return { ok: true, filas: resultado.filas };
}

export interface FilaResultado {
  fila: number;
  icc: string;
  ok: boolean;
  accion?: "creada" | "actualizada" | "sin_cambios";
  error?: string;
}

/** Si esta fila reclama un número corto que hoy tiene OTRA sim, y el usuario
 *  eligió reasignarlo: le quita el número a esa otra SIM y la deja
 *  "Desactivada" (un número corto no puede estar activo en dos SIM a la vez).
 *  Devuelve un error para mostrar en la fila si algo falla en el camino. */
async function resolverConflictoNumeroCorto(
  supabase: Awaited<ReturnType<typeof createClient>>,
  f: FilaParseada,
  userId: string,
  operacionId: string
): Promise<{ error?: string; aplicarNumero: boolean }> {
  if (!f.numeroCortoConflictoIcc) return { aplicarNumero: true };
  if (f.resolucionNumeroCorto === "no_cargar") return { aplicarNumero: false };

  const { data: otraSim } = await supabase
    .from("sim_cards").select("id").eq("icc", f.numeroCortoConflictoIcc).maybeSingle();
  if (!otraSim) return { aplicarNumero: true }; // ya no existe, nada que liberar

  const otraSimId = otraSim.id as string;

  const { error: errorLiberar } = await supabase
    .from("sim_short_numbers")
    .update({ unassigned_at: new Date().toISOString() })
    .eq("sim_id", otraSimId)
    .eq("numero_corto", f.numeroCorto)
    .is("unassigned_at", null);
  if (errorLiberar) return { error: `No se pudo liberar el número corto de la SIM ${f.numeroCortoConflictoIcc}: ${errorLiberar.message}`, aplicarNumero: false };

  const { data: estadoOtraSim } = await supabase
    .from("sim_status_history").select("estado").eq("sim_id", otraSimId)
    .order("changed_at", { ascending: false }).limit(1).maybeSingle();

  const { error: errorDesactivar } = await supabase.from("sim_status_history").insert({
    sim_id: otraSimId,
    estado: "Desactivada",
    estado_anterior: estadoOtraSim?.estado ?? null,
    changed_by: userId,
    nota: `Desactivada automáticamente: su número corto ${f.numeroCorto} se reasignó a la SIM ${f.icc} (carga masiva).`,
    bulk_operation_id: operacionId,
  });
  if (errorDesactivar) return { error: `Se liberó el número corto de ${f.numeroCortoConflictoIcc}, pero no se pudo desactivarla: ${errorDesactivar.message}`, aplicarNumero: false };

  return { aplicarNumero: true };
}

// Cuántas filas se insertan juntas en una sola operación — 6.000+ filas
// pasaban de decenas de miles de idas y vueltas a la base de datos (una por
// cada paso de cada fila) a unas pocas docenas, evitando el error de
// "tiempo agotado" en cargas grandes. Si algo falla dentro de un lote, ese
// lote puntual se reintenta fila por fila para no perder precisión sobre
// cuál fila específica fue la que falló.
const TAMANO_LOTE_INSERCION = 200;

/** Crea UNA SIM nueva con toda su hoja de vida inicial — es la ruta lenta
 *  pero precisa, usada como respaldo cuando un lote completo falla. */
async function crearSimIndividual(
  supabase: Awaited<ReturnType<typeof createClient>>,
  organizationId: string,
  f: FilaParseada,
  userId: string,
  operacionId: string
): Promise<FilaResultado> {
  const cliente = f.clienteResuelto.trim();

  const { data: simCard, error: simError } = await supabase
    .from("sim_cards")
    .insert({ organization_id: organizationId, icc: f.icc, proveedor: f.proveedor, apn: f.apn || null, observaciones: f.observaciones || null, created_by: userId })
    .select("id")
    .single();
  if (simError) return { fila: f.fila, icc: f.icc, ok: false, error: simError.message };
  const simId = simCard.id as string;

  const { error: errorEstado } = await supabase.from("sim_status_history").insert({ sim_id: simId, estado: f.estado, changed_by: userId, nota: "Estado inicial (carga masiva).", bulk_operation_id: operacionId });
  if (errorEstado) {
    await supabase.from("sim_cards").delete().eq("id", simId);
    return { fila: f.fila, icc: f.icc, ok: false, error: `No se pudo registrar el estado: ${errorEstado.message}` };
  }

  if (f.numeroCorto) {
    const { error: errorConflicto, aplicarNumero } = await resolverConflictoNumeroCorto(supabase, f, userId, operacionId);
    if (errorConflicto) {
      await supabase.from("sim_cards").delete().eq("id", simId);
      return { fila: f.fila, icc: f.icc, ok: false, error: errorConflicto };
    }
    if (aplicarNumero) {
      const { error: errorNumero } = await supabase.from("sim_short_numbers").insert({ sim_id: simId, organization_id: organizationId, numero_corto: f.numeroCorto, assigned_by: userId });
      if (errorNumero) {
        await supabase.from("sim_cards").delete().eq("id", simId);
        return { fila: f.fila, icc: f.icc, ok: false, error: `No se pudo registrar el número corto: ${errorNumero.message}` };
      }
    }
  }

  const { error: errorAsignacion } = await supabase.from("sim_assignments").insert({
    sim_id: simId, cliente_nombre: cliente, plan_unidad: f.planUnidad, plan_cantidad: Number(f.planCantidad),
    tipo_plan: f.tipoPlan, pago_momento: f.pagoMomento, precio_cliente: Number(f.precio),
    comercial_id: f.comercialId, broker_id: f.brokerId || null, fecha_entrega: f.fechaEntrega, created_by: userId,
    bulk_operation_id: operacionId,
  });
  if (errorAsignacion) {
    await supabase.from("sim_cards").delete().eq("id", simId);
    return { fila: f.fila, icc: f.icc, ok: false, error: `No se pudo asignar el cliente/plan: ${errorAsignacion.message}` };
  }

  return { fila: f.fila, icc: f.icc, ok: true, accion: "creada" };
}

/** Crea un LOTE de SIM nuevas de una sola vez (una llamada por tabla, no
 *  una por fila). Si algo sale mal con el lote completo, se reintenta fila
 *  por fila automáticamente para no perder ninguna fila válida por culpa
 *  de una sola fila problemática. */
async function crearLoteDeSims(
  supabase: Awaited<ReturnType<typeof createClient>>,
  organizationId: string,
  lote: FilaParseada[],
  userId: string,
  operacionId: string
): Promise<FilaResultado[]> {
  try {
    const { data: simsCreadas, error: errorSims } = await supabase
      .from("sim_cards")
      .insert(lote.map((f) => ({
        organization_id: organizationId, icc: f.icc, proveedor: f.proveedor,
        apn: f.apn || null, observaciones: f.observaciones || null, created_by: userId,
      })))
      .select("id, icc");
    if (errorSims || !simsCreadas) throw new Error(errorSims?.message ?? "No se crearon las SIM del lote.");

    const iccASimId = new Map(simsCreadas.map((s) => [s.icc as string, s.id as string]));

    const { error: errorEstados } = await supabase.from("sim_status_history").insert(
      lote.map((f) => ({
        sim_id: iccASimId.get(f.icc), estado: f.estado, changed_by: userId,
        nota: "Estado inicial (carga masiva).", bulk_operation_id: operacionId,
      }))
    );
    if (errorEstados) throw new Error(`No se pudo registrar el estado inicial del lote: ${errorEstados.message}`);

    // Los conflictos de número corto son poco frecuentes — solo se resuelven
    // (uno por uno, porque cada resolución afecta a OTRA sim distinta) para
    // las pocas filas del lote que de verdad los tienen.
    const filasConNumero: FilaParseada[] = [];
    for (const f of lote) {
      if (!f.numeroCorto) continue;
      if (f.numeroCortoConflictoIcc) {
        const { error: errorConflicto, aplicarNumero } = await resolverConflictoNumeroCorto(supabase, f, userId, operacionId);
        if (errorConflicto) throw new Error(errorConflicto);
        if (aplicarNumero) filasConNumero.push(f);
      } else {
        filasConNumero.push(f);
      }
    }
    if (filasConNumero.length > 0) {
      const { error: errorNumeros } = await supabase.from("sim_short_numbers").insert(
        filasConNumero.map((f) => ({
          sim_id: iccASimId.get(f.icc), organization_id: organizationId,
          numero_corto: f.numeroCorto, assigned_by: userId,
        }))
      );
      if (errorNumeros) throw new Error(`No se pudieron registrar los números cortos del lote: ${errorNumeros.message}`);
    }

    const { error: errorAsignaciones } = await supabase.from("sim_assignments").insert(
      lote.map((f) => ({
        sim_id: iccASimId.get(f.icc), cliente_nombre: f.clienteResuelto.trim(), plan_unidad: f.planUnidad,
        plan_cantidad: Number(f.planCantidad), tipo_plan: f.tipoPlan, pago_momento: f.pagoMomento,
        precio_cliente: Number(f.precio), comercial_id: f.comercialId, broker_id: f.brokerId || null,
        fecha_entrega: f.fechaEntrega, created_by: userId, bulk_operation_id: operacionId,
      }))
    );
    if (errorAsignaciones) throw new Error(`No se pudo asignar cliente/plan en el lote: ${errorAsignaciones.message}`);

    return lote.map((f) => ({ fila: f.fila, icc: f.icc, ok: true, accion: "creada" as const }));
  } catch {
    // Algo del lote falló — se reintenta fila por fila para aislar
    // exactamente cuál (o cuáles) filas son las problemáticas, sin perder
    // las demás filas válidas del mismo lote.
    const resultados: FilaResultado[] = [];
    for (const f of lote) {
      resultados.push(await crearSimIndividual(supabase, organizationId, f, userId, operacionId));
    }
    return resultados;
  }
}

/** FASE 2: guarda de verdad, ya con las decisiones del usuario sobre cada cliente ambiguo. */
export async function confirmarCargaMasiva(filas: FilaParseada[]) {
  const { userId, profile } = await getCurrentProfile();
  const supabase = await createClient();

  const { data: operacion, error: errorOperacion } = await supabase
    .from("bulk_operations")
    .insert({
      organization_id: profile.organization_id,
      tipo: "registro_entrega",
      cantidad_sims: 0, // se actualiza al final, con el conteo real de filas afectadas
      nota: `Carga masiva desde Excel (${filas.length} filas)`,
      created_by: userId,
    })
    .select("id")
    .single();

  if (errorOperacion) return { error: errorOperacion.message };
  const operacionId = operacion.id as string;

  const resultados: FilaResultado[] = [];
  let creadas = 0;
  let actualizadas = 0;
  let sinCambios = 0;

  const filasValidas = filas.filter((f) => {
    if (f.errores.length > 0) {
      resultados.push({ fila: f.fila, icc: f.icc, ok: false, error: f.errores.join("; ") });
      return false;
    }
    return true;
  });

  // Una sola consulta para saber cuáles ICC ya existen, en vez de una
  // consulta por fila — con miles de filas, esto solo ya evita miles de
  // idas y vueltas a la base de datos.
  const { data: existentes } = await supabase
    .from("sim_cards")
    .select("id, icc, apn, observaciones")
    .in("icc", filasValidas.map((f) => f.icc));
  const iccAExistente = new Map((existentes ?? []).map((s) => [s.icc as string, s]));

  const filasNuevas = filasValidas.filter((f) => !iccAExistente.has(f.icc));
  const filasExistentes = filasValidas.filter((f) => iccAExistente.has(f.icc));

  // ---- SIM nuevas: en lotes, no una por una ----
  for (let i = 0; i < filasNuevas.length; i += TAMANO_LOTE_INSERCION) {
    const lote = filasNuevas.slice(i, i + TAMANO_LOTE_INSERCION);
    const resultadosLote = await crearLoteDeSims(supabase, profile.organization_id, lote, userId, operacionId);
    for (const r of resultadosLote) {
      resultados.push(r);
      if (r.ok) creadas++;
    }
  }

  // ---- SIM que ya existían: se actualizan una por una (son las menos, y
  // cada una necesita comparar contra su estado actual para saber qué
  // cambió realmente) ----
  for (const f of filasExistentes) {
    const cliente = f.clienteResuelto.trim();
    const existente = iccAExistente.get(f.icc)!;
    const simId = existente.id as string;
    let cambio = false;

    const { data: statusActual } = await supabase
      .from("sim_status_history").select("estado").eq("sim_id", simId)
      .order("changed_at", { ascending: false }).limit(1).maybeSingle();
    if (!statusActual || statusActual.estado !== f.estado) {
      const { error: errorEstado } = await supabase.from("sim_status_history").insert({
        sim_id: simId, estado: f.estado, changed_by: userId, nota: "Actualizado por carga masiva.",
        estado_anterior: statusActual?.estado ?? null, bulk_operation_id: operacionId,
      });
      if (errorEstado) {
        resultados.push({ fila: f.fila, icc: f.icc, ok: false, error: `No se pudo actualizar el estado: ${errorEstado.message}` });
        continue;
      }
      cambio = true;
    }

    if (f.numeroCorto) {
      const { data: numeroActual } = await supabase
        .from("sim_short_numbers").select("numero_corto").eq("sim_id", simId).is("unassigned_at", null).maybeSingle();
      if (!numeroActual || numeroActual.numero_corto !== f.numeroCorto) {
        const { error: errorConflicto, aplicarNumero } = await resolverConflictoNumeroCorto(supabase, f, userId, operacionId);
        if (errorConflicto) {
          resultados.push({ fila: f.fila, icc: f.icc, ok: false, error: errorConflicto });
          continue;
        }
        if (aplicarNumero) {
          await supabase.from("sim_short_numbers").update({ unassigned_at: new Date().toISOString() }).eq("sim_id", simId).is("unassigned_at", null);
          const { error: errorNumero } = await supabase.from("sim_short_numbers").insert({ sim_id: simId, organization_id: profile.organization_id, numero_corto: f.numeroCorto, assigned_by: userId });
          if (errorNumero) {
            resultados.push({ fila: f.fila, icc: f.icc, ok: false, error: `No se pudo actualizar el número corto: ${errorNumero.message}` });
            continue;
          }
          cambio = true;
        }
      }
    }

    // Si la persona eligió "solo cambiar el estado" para esta SIM ya
    // existente, no se toca su cliente/plan/precio actual aunque el Excel
    // traiga datos distintos — solo se actualiza el estado (y el número
    // corto, que es parte de la identidad física de la SIM, no de la entrega).
    const soloEstado = !f.esNueva && f.accionExistente === "solo_estado";

    const asigActualRes = soloEstado
      ? null
      : await supabase.from("sim_assignments").select("*").eq("sim_id", simId).is("ended_at", null).maybeSingle();
    const asigActual = asigActualRes?.data;
    const asigCambio = !soloEstado && (
      !asigActual
      || asigActual.cliente_nombre !== cliente
      || asigActual.plan_unidad !== f.planUnidad
      || Number(asigActual.plan_cantidad) !== Number(f.planCantidad)
      || asigActual.tipo_plan !== f.tipoPlan
      || asigActual.pago_momento !== f.pagoMomento
      || Number(asigActual.precio_cliente) !== Number(f.precio)
      || asigActual.comercial_id !== f.comercialId
      || (asigActual.broker_id || null) !== (f.brokerId || null)
      || asigActual.fecha_entrega !== f.fechaEntrega
    );

    if (asigCambio) {
      if (asigActual) {
        await supabase.from("sim_assignments").update({ ended_at: new Date().toISOString(), ended_by_bulk_operation_id: operacionId }).eq("sim_id", simId).is("ended_at", null);
      }
      const { error: errorAsignacion } = await supabase.from("sim_assignments").insert({
        sim_id: simId, cliente_nombre: cliente, plan_unidad: f.planUnidad, plan_cantidad: Number(f.planCantidad),
        tipo_plan: f.tipoPlan, pago_momento: f.pagoMomento, precio_cliente: Number(f.precio),
        comercial_id: f.comercialId, broker_id: f.brokerId || null, fecha_entrega: f.fechaEntrega, created_by: userId,
        bulk_operation_id: operacionId,
      });
      if (errorAsignacion) {
        resultados.push({ fila: f.fila, icc: f.icc, ok: false, error: `No se pudo asignar el cliente/plan: ${errorAsignacion.message}` });
        continue;
      }
      cambio = true;
    }

    const nuevoApn = f.apn || null;
    const nuevaObs = f.observaciones || null;
    if (nuevoApn !== (existente.apn ?? null) || nuevaObs !== (existente.observaciones ?? null)) {
      await supabase.from("sim_cards").update({ apn: nuevoApn, observaciones: nuevaObs }).eq("id", simId);
      cambio = true;
    }

    if (cambio) { actualizadas++; resultados.push({ fila: f.fila, icc: f.icc, ok: true, accion: "actualizada" }); }
    else { sinCambios++; resultados.push({ fila: f.fila, icc: f.icc, ok: true, accion: "sin_cambios" }); }
  }

  await supabase.from("bulk_operations").update({ cantidad_sims: creadas + actualizadas }).eq("id", operacionId);

  revalidatePath("/dashboard"); revalidatePath("/dashboard/inventario"); revalidatePath("/dashboard/nueva");
  return { ok: true, creadas, actualizadas, sinCambios, resultados };
}
