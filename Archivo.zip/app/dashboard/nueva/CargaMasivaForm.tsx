"use client";

import { useState, useTransition, useRef } from "react";
import { analizarCargaMasiva, confirmarCargaMasiva, FilaParseada, FilaResultado } from "./actions";
import { traducirError } from "@/lib/friendlyError";

type Fase = "subir" | "revisar" | "listo";

// Tamaño de cada tanda que el navegador manda al confirmar — chico a
// propósito para que la llamada nunca se acerque a ningún límite de tamaño
// del servidor, sin importar cuánto pese cada fila ni qué límite tenga
// configurado el servidor en un momento dado.
const TAMANO_TANDA_CONFIRMACION = 300;

export default function CargaMasivaForm() {
  const [fase, setFase] = useState<Fase>("subir");
  const [filas, setFilas] = useState<FilaParseada[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [resultado, setResultado] = useState<{ creadas: number; actualizadas: number; sinCambios: number; resultados: FilaResultado[] } | null>(null);
  const [nombreArchivo, setNombreArchivo] = useState<string | null>(null);
  const [arrastrando, setArrastrando] = useState(false);
  const [isPending, startTransition] = useTransition();
  const [progreso, setProgreso] = useState<{ hechas: number; total: number } | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  function asignarArchivo(file: File) {
    if (fileRef.current) {
      const dt = new DataTransfer();
      dt.items.add(file);
      fileRef.current.files = dt.files;
    }
    setNombreArchivo(file.name);
  }

  function handleSeleccionArchivo(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (file) setNombreArchivo(file.name);
  }

  function handleDrop(e: React.DragEvent) {
    e.preventDefault();
    setArrastrando(false);
    const file = e.dataTransfer.files?.[0];
    if (file) asignarArchivo(file);
  }

  function handleAnalizar(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    const file = fileRef.current?.files?.[0];
    if (!file) { setError("Selecciona un archivo .xlsx."); return; }
    const formData = new FormData();
    formData.append("archivo", file);

    startTransition(async () => {
      const res = await analizarCargaMasiva(formData);
      if (res?.error) setError(traducirError(res.error));
      else if (res?.ok) { setFilas(res.filas); setFase("revisar"); }
    });
  }

  function resolverCliente(fila: number, valor: string) {
    setFilas((prev) => prev.map((f) => (f.fila === fila ? { ...f, clienteResuelto: valor } : f)));
  }

  function resolverAccionExistente(fila: number, valor: "reemplazar" | "solo_estado") {
    setFilas((prev) => prev.map((f) => (f.fila === fila ? { ...f, accionExistente: valor } : f)));
  }

  function resolverNumeroCorto(fila: number, valor: "reasignar" | "no_cargar") {
    setFilas((prev) => prev.map((f) => (f.fila === fila ? { ...f, resolucionNumeroCorto: valor } : f)));
  }

  function handleConfirmar() {
    setProgreso({ hechas: 0, total: filas.length });
    startTransition(async () => {
      const acumulado = { creadas: 0, actualizadas: 0, sinCambios: 0, resultados: [] as FilaResultado[] };

      for (let i = 0; i < filas.length; i += TAMANO_TANDA_CONFIRMACION) {
        const tanda = filas.slice(i, i + TAMANO_TANDA_CONFIRMACION);
        try {
          const res = await confirmarCargaMasiva(tanda);
          acumulado.creadas += res.creadas ?? 0;
          acumulado.actualizadas += res.actualizadas ?? 0;
          acumulado.sinCambios += res.sinCambios ?? 0;
          acumulado.resultados.push(...(res.resultados ?? []));
          if (res.error) {
            // Un error a nivel de toda la tanda (no de una fila puntual) —
            // se registra para cada fila de esa tanda y se sigue con las
            // siguientes, para no perder el resto de la carga por una tanda.
            for (const f of tanda) acumulado.resultados.push({ fila: f.fila, icc: f.icc, ok: false, error: res.error });
          }
        } catch (e) {
          const mensaje = e instanceof Error ? e.message : "Error desconocido al confirmar esta tanda.";
          for (const f of tanda) acumulado.resultados.push({ fila: f.fila, icc: f.icc, ok: false, error: mensaje });
        }
        setProgreso({ hechas: Math.min(i + TAMANO_TANDA_CONFIRMACION, filas.length), total: filas.length });
      }

      setResultado(acumulado);
      setProgreso(null);
      setFase("listo");
    });
  }

  function reiniciar() {
    setFase("subir");
    setFilas([]);
    setResultado(null);
    setError(null);
    setNombreArchivo(null);
    if (fileRef.current) fileRef.current.value = "";
  }

  const filasConError = filas.filter((f) => f.errores.length > 0);
  const filasConClienteAmbiguo = filas.filter((f) => f.errores.length === 0 && f.clienteSugerido);
  const filasListas = filas.filter((f) => f.errores.length === 0 && !f.clienteSugerido);
  const filasNuevas = filasListas.filter((f) => f.esNueva);
  const filasExistentes = filasListas.filter((f) => !f.esNueva);
  const filasConConflictoNumero = filas.filter((f) => f.errores.length === 0 && f.numeroCortoConflictoIcc);
  const errores = resultado?.resultados.filter((r) => !r.ok) ?? [];

  return (
    <section className="rounded-xl border bg-white p-6" style={{ borderColor: "var(--border)" }}>
      <div className="flex items-center justify-between mb-3">
        <h2 className="font-display text-base font-semibold">Carga masiva desde Excel</h2>
        <a
          href="/dashboard/nueva/plantilla"
          className="text-sm font-medium rounded-lg border px-3 py-1.5"
          style={{ borderColor: "var(--border)" }}
        >
          Descargar plantilla
        </a>
      </div>

      {fase === "subir" && (
        <>
          <p className="text-sm mb-4" style={{ color: "var(--text-secondary)" }}>
            La plantilla ya trae listas desplegables (proveedor, APN, plan, comercial, etc.) tomadas
            de la configuración actual, para evitar errores de escritura. Cada fila es una entrega
            completa; si el ICC ya existe, se actualiza y el cambio queda en su hoja de vida.
          </p>
          <form onSubmit={handleAnalizar} className="flex flex-col gap-3">
            <label
              htmlFor="sim-file-input"
              onDragOver={(e) => { e.preventDefault(); setArrastrando(true); }}
              onDragLeave={() => setArrastrando(false)}
              onDrop={handleDrop}
              className="flex flex-col items-center justify-center gap-1.5 rounded-lg border-2 border-dashed px-6 py-8 text-center cursor-pointer transition"
              style={{
                borderColor: arrastrando ? "var(--chip-gold)" : "var(--border)",
                background: arrastrando ? "var(--bg)" : "white",
              }}
            >
              <span style={{ fontSize: "1.75rem" }}>📄</span>
              <span className="text-sm font-medium">
                {nombreArchivo ?? "Arrastra tu Excel aquí, o haz clic para elegirlo"}
              </span>
              <span className="text-xs" style={{ color: "var(--text-muted)" }}>Solo archivos .xlsx</span>
            </label>
            <input id="sim-file-input" ref={fileRef} type="file" accept=".xlsx" onChange={handleSeleccionArchivo} className="hidden" />
            <button
              type="submit"
              disabled={isPending}
              className="rounded-lg px-4 py-2 text-sm font-semibold text-white disabled:opacity-60 self-start hover:underline cursor-pointer"
              style={{ background: "var(--ink-900)" }}
            >
              {isPending ? "Analizando…" : "Revisar archivo"}
            </button>
          </form>
          {error && (
            <p className="text-sm rounded-lg px-3 py-2 mt-3" style={{ background: "#FDEAEA", color: "var(--state-desactivada)" }}>
              {error}
            </p>
          )}
        </>
      )}

      {fase === "revisar" && (
        <div>
          <p className="text-sm mb-4" style={{ color: "var(--text-secondary)" }}>
            {filasListas.length} lista(s) para cargar, {filasConClienteAmbiguo.length} necesitan confirmar el cliente, {filasConError.length} con error.
          </p>

          {filasConConflictoNumero.length > 0 && (
            <div className="mb-5">
              <h3 className="text-sm font-semibold mb-2" style={{ color: "var(--state-desactivada-temp)" }}>
                Estos números cortos ya están en otra SIM
              </h3>
              <div className="flex flex-col gap-3">
                {filasConConflictoNumero.map((f) => (
                  <div key={f.fila} className="rounded-lg border p-3" style={{ borderColor: "var(--state-desactivada-temp)", background: "#FFF6EE" }}>
                    <p className="text-sm mb-2">
                      Fila {f.fila} (ICC <span className="font-mono">{f.icc}</span>): el número corto{" "}
                      <span className="font-mono font-medium">{f.numeroCorto}</span> ya está asignado a la SIM{" "}
                      <span className="font-mono font-medium">{f.numeroCortoConflictoIcc}</span>.
                    </p>
                    <div className="flex flex-col gap-1.5">
                      <label className="flex items-center gap-1.5 text-sm">
                        <input
                          type="radio"
                          name={`numero-${f.fila}`}
                          checked={f.resolucionNumeroCorto === "reasignar"}
                          onChange={() => resolverNumeroCorto(f.fila, "reasignar")}
                        />
                        Sí, asignar este número a la SIM {f.icc} — la SIM {f.numeroCortoConflictoIcc} quedará <strong>Desactivada</strong>
                      </label>
                      <label className="flex items-center gap-1.5 text-sm">
                        <input
                          type="radio"
                          name={`numero-${f.fila}`}
                          checked={f.resolucionNumeroCorto === "no_cargar"}
                          onChange={() => resolverNumeroCorto(f.fila, "no_cargar")}
                        />
                        No, dejar el número donde está — esta fila se carga sin número corto
                      </label>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {filasExistentes.length > 0 && (
            <div className="mb-5">
              <h3 className="text-sm font-semibold mb-2">
                {filasExistentes.length} de estos ICC ya están en el inventario
              </h3>
              <p className="text-sm mb-3" style={{ color: "var(--text-secondary)" }}>
                Elige qué hacer con cada una. El cambio queda registrado en su hoja de vida de todas formas.
              </p>
              <div className="flex flex-col gap-3">
                {filasExistentes.map((f) => (
                  <div key={f.fila} className="rounded-lg border p-3" style={{ borderColor: "var(--border)", background: "var(--chip-gold-soft)" }}>
                    <p className="text-sm mb-2">
                      Fila {f.fila} (ICC <span className="font-mono">{f.icc}</span>) ya existe.
                    </p>
                    <div className="flex flex-col gap-1.5">
                      <label className="flex items-center gap-1.5 text-sm">
                        <input
                          type="radio"
                          name={`existente-${f.fila}`}
                          checked={f.accionExistente === "reemplazar"}
                          onChange={() => resolverAccionExistente(f.fila, "reemplazar")}
                        />
                        Reemplazar tal cual con lo del archivo (estado, cliente, plan y precio)
                      </label>
                      <label className="flex items-center gap-1.5 text-sm">
                        <input
                          type="radio"
                          name={`existente-${f.fila}`}
                          checked={f.accionExistente === "solo_estado"}
                          onChange={() => resolverAccionExistente(f.fila, "solo_estado")}
                        />
                        Solo cambiar el estado — dejar el cliente/plan actual sin tocar
                      </label>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {filasConClienteAmbiguo.length > 0 && (
            <div className="mb-5">
              <h3 className="text-sm font-semibold mb-2">Confirma estos clientes</h3>
              <div className="flex flex-col gap-3">
                {filasConClienteAmbiguo.map((f) => (
                  <div key={f.fila} className="rounded-lg border p-3" style={{ borderColor: "var(--border)" }}>
                    <p className="text-sm mb-2">
                      Fila {f.fila} (ICC <span className="font-mono">{f.icc}</span>): escribiste{" "}
                      <span className="font-medium">&ldquo;{f.clienteEscrito}&rdquo;</span>. Encontré un cliente parecido:{" "}
                      <span className="font-medium">&ldquo;{f.clienteSugerido}&rdquo;</span>. ¿Es el mismo?
                    </p>
                    <div className="flex gap-4">
                      <label className="flex items-center gap-1.5 text-sm">
                        <input
                          type="radio"
                          name={`cliente-${f.fila}`}
                          checked={f.clienteResuelto === f.clienteSugerido}
                          onChange={() => resolverCliente(f.fila, f.clienteSugerido!)}
                        />
                        Sí, asignar a &ldquo;{f.clienteSugerido}&rdquo;
                      </label>
                      <label className="flex items-center gap-1.5 text-sm">
                        <input
                          type="radio"
                          name={`cliente-${f.fila}`}
                          checked={f.clienteResuelto === f.clienteEscrito}
                          onChange={() => resolverCliente(f.fila, f.clienteEscrito)}
                        />
                        No, es un cliente nuevo (&ldquo;{f.clienteEscrito}&rdquo;)
                      </label>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {filasConError.length > 0 && (
            <div className="mb-5">
              <h3 className="text-sm font-semibold mb-2" style={{ color: "var(--state-desactivada)" }}>
                Estas filas no se van a cargar
              </h3>
              <div className="rounded-lg border overflow-hidden" style={{ borderColor: "var(--border)" }}>
                <table className="w-full text-sm">
                  <thead>
                    <tr className="text-left border-b" style={{ borderColor: "var(--border)", color: "var(--text-secondary)" }}>
                      <th className="px-3 py-2">Fila</th>
                      <th className="px-3 py-2">ICC</th>
                      <th className="px-3 py-2">Error</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filasConError.map((f) => (
                      <tr key={f.fila} className="border-b last:border-0" style={{ borderColor: "var(--border)" }}>
                        <td className="px-3 py-2">{f.fila}</td>
                        <td className="px-3 py-2 font-mono">{f.icc || "—"}</td>
                        <td className="px-3 py-2" style={{ color: "var(--state-desactivada)" }}>{f.errores.join("; ")}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {error && (
            <p className="text-sm rounded-lg px-3 py-2 mb-4" style={{ background: "#FDEAEA", color: "var(--state-desactivada)" }}>
              {error}
            </p>
          )}

          {progreso && (
            <div className="mb-4">
              <div className="h-2 rounded-full overflow-hidden" style={{ background: "var(--border)" }}>
                <div
                  className="h-full transition-all"
                  style={{ width: `${Math.round((progreso.hechas / progreso.total) * 100)}%`, background: "var(--ink-900)" }}
                />
              </div>
              <p className="text-xs mt-1.5" style={{ color: "var(--text-muted)" }}>
                Guardando {progreso.hechas} de {progreso.total} — se manda en tandas chicas para que nunca falle por tamaño, esto puede tardar un poco con archivos grandes.
              </p>
            </div>
          )}

          <div className="flex gap-3">
            <button
              onClick={handleConfirmar}
              disabled={isPending || filas.length === filasConError.length}
              className="rounded-lg px-4 py-2 text-sm font-semibold text-white disabled:opacity-60"
              style={{ background: "var(--ink-900)" }}
            >
              {isPending
                ? progreso
                  ? `Guardando… (${progreso.hechas}/${progreso.total})`
                  : "Guardando…"
                : filasExistentes.length > 0
                  ? `Confirmar: crear ${filasNuevas.length} y actualizar ${filasExistentes.length}`
                  : `Confirmar y cargar ${filas.length - filasConError.length} SIM`}
            </button>
            <button onClick={reiniciar} className="rounded-lg border px-4 py-2 text-sm font-medium bg-white" style={{ borderColor: "var(--border)" }}>
              Cancelar
            </button>
          </div>
        </div>
      )}

      {fase === "listo" && resultado && (
        <div>
          {(() => {
            const huboExito = resultado.creadas + resultado.actualizadas + resultado.sinCambios > 0;
            const todoFallo = errores.length > 0 && !huboExito;
            const estilo = todoFallo
              ? { background: "#FDEAEA", color: "var(--state-desactivada)" }
              : errores.length > 0
                ? { background: "#FDF3E4", color: "var(--state-lista)" }
                : { background: "#E7F5EC", color: "var(--state-activa)" };
            return (
              <p className="text-sm rounded-lg px-3 py-2 mb-3 font-medium" style={estilo}>
                {todoFallo
                  ? `No se cargó ninguna SIM — ${errores.length} con error. Revisa el detalle abajo.`
                  : <>
                      {resultado.creadas} creada{resultado.creadas === 1 ? "" : "s"} · {resultado.actualizadas} actualizada{resultado.actualizadas === 1 ? "" : "s"} (se guardó el cambio en su hoja de vida) · {resultado.sinCambios} sin cambios
                      {errores.length > 0 && ` · ${errores.length} con error`}
                    </>
                }
              </p>
            );
          })()}
          {errores.length > 0 && (
            <div className="rounded-lg border overflow-hidden mb-3" style={{ borderColor: "var(--border)" }}>
              <table className="w-full text-sm">
                <thead>
                  <tr className="text-left border-b" style={{ borderColor: "var(--border)", color: "var(--text-secondary)" }}>
                    <th className="px-3 py-2">Fila</th><th className="px-3 py-2">ICC</th><th className="px-3 py-2">Error</th>
                  </tr>
                </thead>
                <tbody>
                  {errores.map((e) => (
                    <tr key={e.fila} className="border-b last:border-0" style={{ borderColor: "var(--border)" }}>
                      <td className="px-3 py-2">{e.fila}</td>
                      <td className="px-3 py-2 font-mono">{e.icc || "—"}</td>
                      <td className="px-3 py-2" style={{ color: "var(--state-desactivada)" }}>{traducirError(e.error)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
          <button onClick={reiniciar} className="rounded-lg border px-4 py-2 text-sm font-medium bg-white" style={{ borderColor: "var(--border)" }}>
            Cargar otro archivo
          </button>
        </div>
      )}
    </section>
  );
}
